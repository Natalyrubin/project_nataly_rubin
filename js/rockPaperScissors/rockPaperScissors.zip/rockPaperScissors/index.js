'use strict'


let playerScore = 0;
let coputerScore = 0;
let gameCounter = 0;






const playerScreenScore = document.querySelector('.player-score');
const computerScreenScore = document.querySelector('.computer-score');
const rockId = document.querySelector('#rock');
const paperId = document.querySelector('#paper');
const scissorsId = document.querySelector('#scissors');
const result = document.querySelector('#result');
const computerChoice = document.querySelector('#computer-choice');
const playAgain = document.querySelector('#play-again');

const choiceButtons = document.querySelector('.choices');







playerScreenScore.innerText = ` Player Scores: ${playerScore}`;
computerScreenScore.innerText = ` Computer Scores: ${coputerScore}`;



let computerRandomChoise = 0;

function randComputerChoice() {
    computerRandomChoise = Math.trunc((Math.random() * 3) + 1);
    console.log("Computer Choise Is:", computerRandomChoise);
}






function rock() {
    randComputerChoice()
    {
        if (computerRandomChoise === 1) {
            computerChoice.innerHTML = `<br><br> <p> Computer Choice: </p> <i class="fas fa-hand-rock" style="border: 2px solid var(--main-color); border-radius: 10px; margin: 10px 2rem; padding: 1rem; background-color:  #660033; align-items: center; color: white;"></i>`;
            result.innerHTML = `<p> Rock VS Rock - It's a TIE </p>`;
        }

        if (computerRandomChoise === 2) {
            computerChoice.innerHTML = `<br><br> <p> Computer Choice: </p> <i class="fas fa-hand-paper" style="border: 2px solid var(--main-color); border-radius: 10px; margin: 10px 2rem; padding: 1rem; background-color:  #660033; align-items: center; color: white;"></i>`;
            result.innerHTML = `<p> Rock VS Paper - Computer win</p>`;
            coputerScore += 1;
            console.log(`computer scores is: ${coputerScore}`);
            computerScreenScore.innerText = ` Computer Scores: ${coputerScore}`;
        }

        if (computerRandomChoise === 3) {
            computerChoice.innerHTML = `<br><br> <p> Computer Choice: </p> <i class="fas fa-hand-scissors" style="border: 2px solid var(--main-color); border-radius: 10px; margin: 10px 2rem; padding: 1rem; background-color:  #660033; align-items: center; color: white;"></i>`;
            result.innerHTML = `<p> Rock VS Scissors - You win</p>`;
            playerScore += 1;
            console.log(`player scores is: ${playerScore}`);
            playerScreenScore.innerText = ` Player Scores: ${playerScore}`;
        }

    }
    gameCounter++;
    counter();
    console.log(`Game Number is: ${gameCounter}`);
}





function paper() {
    randComputerChoice()
    {
        if (computerRandomChoise === 1) {
            computerChoice.innerHTML = `<br><br> <p> Computer Choice: </p> <i class="fas fa-hand-rock" style="border: 2px solid var(--main-color); border-radius: 10px; margin: 10px 2rem; padding: 1rem; background-color: #660033; align-items: center; color: white;"></i>`;
            result.innerText = "Paper VS Rock - You win";
            playerScore += 1;
            playerScreenScore.innerText = ` Player Scores: ${playerScore}`;
        }

        if (computerRandomChoise === 2) {
            computerChoice.innerHTML = `<br><br> <p> Computer Choice: </p> <i class="fas fa-hand-paper" style="border: 2px solid var(--main-color); border-radius: 10px; margin: 10px 2rem; padding: 1rem; background-color: #660033; align-items: center; color: white;"></i>`;
            result.innerText = "Paper VS Paper - It's a TIE";
        }

        if (computerRandomChoise === 3) {
            computerChoice.innerHTML = `<br><br> <p> Computer Choice: </p> <i class="fas fa-hand-scissors" style="border: 2px solid var(--main-color); border-radius: 10px; margin: 10px 2rem; padding: 1rem; background-color: #660033; align-items: center; color: white;"></i>`;
            result.innerText = "Paper VS Scissors - Computer win";
            coputerScore += 1;
            computerScreenScore.innerText = ` Computer Scores: ${coputerScore}`;
        }

    }
    gameCounter++;
    counter();
    console.log(`Game Number is: ${gameCounter}`);
}





function scissors() {
    randComputerChoice()
    {
        if (computerRandomChoise === 1) {
            computerChoice.innerHTML = `<br><br> <p> Computer Choice: </p> <i class="fas fa-hand-rock" style="border: 2px solid var(--main-color); border-radius: 10px; margin: 10px 2rem; padding: 1rem; background-color: #660033; align-items: center; color: white;"></i>`;
            result.innerText = "Scissors VS Rock - Computer win";
            coputerScore += 1;
            computerScreenScore.innerText = ` Computer Scores: ${coputerScore}`;
        }

        if (computerRandomChoise === 2) {
            computerChoice.innerHTML = `<br><br> <p> Computer Choice: </p> <i class="fas fa-hand-paper" style="border: 2px solid var(--main-color); border-radius: 10px; margin: 10px 2rem; padding: 1rem; background-color: #660033; align-items: center; color: white;"></i>`;
            result.innerText = "Scissors VS Paper - You win";
            playerScore += 1;
            playerScreenScore.innerText = ` Player Scores: ${playerScore}`;
        }

        if (computerRandomChoise === 3) {
            computerChoice.innerHTML = `<br><br> <p> Computer Choice: </p> <i class="fas fa-hand-scissors" style="border: 2px solid var(--main-color); border-radius: 10px; margin: 10px 2rem; padding: 1rem; background-color: #660033; align-items: center; color: white;"></i>`;
            result.innerText = "Scissors VS Scissors - It's a TIE";
        }

    }
    gameCounter++;
    counter();
    console.log(`Game Number is: ${gameCounter}`);
}


function counter() {
    if (gameCounter % 10 === 0) {
        choiceButtons.innerHTML = `<p style="font-size: 45px;" >GAME OVER</p`;
        result.innerText = 'We Finnish';
        if (playerScore > coputerScore) {
            computerChoice.innerText = `The Winner Is: The Player!!!`;
        }
        if (coputerScore > playerScore) {
            computerChoice.innerText = `The Winner Is: The Computer!!!`;
        }
        if (coputerScore === playerScore) {
            computerChoice.innerText = `There is no Winner! It's a TIE - try again.`;
        }
    }
}

console.log(`Game Number is: ${gameCounter}`);


function playagain() {
    playerScore = 0;
    coputerScore = 0;
    playerScreenScore.innerText = ` Player Scores: ${playerScore}`;
    computerScreenScore.innerText = ` Computer Scores: ${coputerScore}`;
    choiceButtons.innerHTML = `<div class="choice" id="rock" onclick="rock()">
    <i class="fas fa-hand-rock"></i>
    </div>
    <div class="choice" id="paper" onclick="paper()">
    <i class="fas fa-hand-paper"></i>
    </div>
    <div class="choice" id="scissors" onclick="scissors()">
    <i class="fas fa-hand-scissors"></i>
    </div>`;
    computerChoice.innerHTML = "";
    result.innerText = "Choose your weapon!";
}





